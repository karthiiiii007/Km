function buttonClick(val){
  
  
  document.getElementById("screen").value+=val;
  
  
  
}
console.log("ready")


function Mindaruth(){
    
  document.getElementById("screen").value="";
}

function HaiHello(){
  document.getElementsByClassName("screen").value=val;
}

function Result(){
var a = document.getElementById('screen');
var result = eval(a);

console.log(result)
}
